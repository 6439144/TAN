import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbBLOB;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;

public class GreetServer_JCN extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		 MbOutputTerminal out = getOutputTerminal("out");

		try (ServerSocket serverSocket = new ServerSocket(
				(Integer) getUserDefinedAttribute("Port"));
				Socket clientSocket = serverSocket.accept();
				PrintWriter outWriter = new PrintWriter(clientSocket.getOutputStream(), true);
				BufferedReader in = new BufferedReader(new InputStreamReader(
						clientSocket.getInputStream()));) {

			String inputLine;
			while (true) {
				if ((inputLine = in.readLine()) != null && ".".equals(inputLine)) {
					break;
				}
				outWriter.println("Server :" + inputLine);
				MbMessage outMessage = new MbMessage();
				MbElement outputRoot = outMessage.getRootElement();
				MbElement inputRoot = inAssembly.getMessage().getRootElement();
				outputRoot.addAsFirstChild(inputRoot.getFirstChild().copy());
				
				MbElement outParser = outputRoot.createElementAsLastChild(MbBLOB.PARSER_NAME);
				outParser.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "BLOB", inputLine.getBytes());
				
				MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly, outMessage);
				out.propagate(outAssembly);
				
			}

		} catch (IOException e) {
			new MbUserException(this, "evaluate()", "","", e.toString(), null);
		}
	}

}
