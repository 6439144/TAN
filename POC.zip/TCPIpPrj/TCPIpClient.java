import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

import javax.swing.JOptionPane;


public class TCPIpClient {
	
	

	public static void main(String[] args) {
		
		System.out.println("Client started");
		try(Socket clientSocket = new Socket("10.249.0.162", 6666);
				PrintWriter outWriter = new PrintWriter(clientSocket.getOutputStream(), true);
				BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
				Scanner scanner = new Scanner(System.in);
				) {
			
			
			
			
			while (true) {
				String text = JOptionPane.showInputDialog("Input");
				System.out.println(text);
				outWriter.println(text);
				String response = in.readLine();
				if (".".equals(text)) {
					System.out.println("Good bye from client");
					break;
				}
				
				System.out.println(response);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		System.out.println("Client stopped");

	}

}
