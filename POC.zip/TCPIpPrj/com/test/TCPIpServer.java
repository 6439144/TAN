package com.test;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;


public class TCPIpServer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		try (ServerSocket serverSocket = new ServerSocket(
				6666);
				Socket clientSocket = serverSocket.accept();
				PrintWriter outWriter = new PrintWriter(clientSocket.getOutputStream(), true);
				BufferedReader in = new BufferedReader(new InputStreamReader(
						clientSocket.getInputStream()));) {

			String inputLine;
			while (true) {
				if ((inputLine = in.readLine()) != null && ".".equals(inputLine)) {
					break;
				}
				outWriter.println("Server :" + inputLine);
			}

	}catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}
		}

}
