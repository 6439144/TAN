package hr.croz.sama;


public class BankResponse {
	
	private Person person;
	private String typeOfInquiredParty;
	private OtherInvolvedParties otherInvolvedParties;
	public OtherInvolvedParties getOtherInvolvedParties() {
		return otherInvolvedParties;
	}

	public void setOtherInvolvedParties(OtherInvolvedParties otherInvolvedParties) {
		this.otherInvolvedParties = otherInvolvedParties;
	}

	public BankResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	public String getTypeOfInquiredParty() {
		return typeOfInquiredParty;
	}

	public void setTypeOfInquiredParty(String typeOfInquiredParty) {
		this.typeOfInquiredParty = typeOfInquiredParty;
	}

}
