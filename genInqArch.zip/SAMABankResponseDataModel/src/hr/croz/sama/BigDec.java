package hr.croz.sama;

import java.math.BigDecimal;

public  class BigDec {

	public static  BigDecimal  init()
	{
		BigDecimal v=new BigDecimal(1000000);
		return v;
		
	}
}
