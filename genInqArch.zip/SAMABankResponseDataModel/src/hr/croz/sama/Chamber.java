package hr.croz.sama;

public class Chamber {
private String id;
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getChamperName() {
	return champerName;
}
public void setChamperName(String champerName) {
	this.champerName = champerName;
}
public String getChamperIdType() {
	return champerIdType;
}
public void setChamperIdType(String champerIdType) {
	this.champerIdType = champerIdType;
}
private String champerName;
private String champerIdType;	
}
