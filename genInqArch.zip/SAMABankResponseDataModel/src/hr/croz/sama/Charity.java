package hr.croz.sama;

public class Charity {
	private  String id;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCharityName() {
		return CharityName;
	}
	public void setCharityName(String charityName) {
		CharityName = charityName;
	}
	public String getCharityIdType() {
		return CharityIdType;
	}
	public void setCharityIdType(String charityIdType) {
		CharityIdType = charityIdType;
	}
	private  String CharityName;
	private  String CharityIdType;
}
