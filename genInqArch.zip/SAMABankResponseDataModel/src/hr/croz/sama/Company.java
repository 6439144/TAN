package hr.croz.sama;

public class Company {
	private  String id;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCompanyName() {
		return CompanyName;
	}
	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}
	public String getCompanyIDType() {
		return CompanyIDType;
	}
	public void setCompanyIDType(String companyIDType) {
		CompanyIDType = companyIDType;
	}
	private  String CompanyName;
	private String CompanyIDType;
}
