package hr.croz.sama;

public class Government {
private String id;
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getGovName() {
	return GovName;
}
public void setGovName(String govName) {
	GovName = govName;
}
public String getGovIdType() {
	return GovIdType;
}
public void setGovIdType(String govIdType) {
	GovIdType = govIdType;
}
private String GovName;
private String GovIdType;
}
