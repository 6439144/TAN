package hr.croz.sama;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Dictionary;









public class InquiryRequest {

	/**
	 * 
	 */
	private ArrayList<MoreInfoDic>  moreInfo=new ArrayList<MoreInfoDic>();
	private Person person;
	private String typeOfInquiredParty;
	private String channelType;
	

	public String getChannelType() {
		return channelType;
	}

	public void setChannelType(String channelType) {
		this.channelType = channelType;
	}

	public ArrayList<MoreInfoDic> getMoreInfo() {
		return moreInfo;
	}

	public String getMoreInfoByKey(String _key) {
		String val="";
		for (MoreInfoDic moreInfoDic : moreInfo) {
			
			
			System.out.println("param"+_key);

			System.out.println("codeee"+moreInfoDic._Key);

			if (moreInfoDic._Key.equals(_key))
			{
				val=moreInfoDic._Value;
				
				
			}
		
		}
		System.out.println("codeee"+val);
		return val;
	}
	public 	Boolean Compare(BigDecimal val1,BigDecimal val2)
	{
		System.out.println("1111"+val1.intValue());;
		System.out.println("2222"+val2.intValue());;

		int x=val1.compareTo(val2);
		System.out.println("xxxx   "+x);;

		if(x>0)
		return true;
		else
		return false;
		
	}
	
	public BigDecimal getMoreInfoIntByKey(String _key) {
		System.out.println("amtttt");;

		String val="";
		for (MoreInfoDic moreInfoDic : moreInfo) {
			if (moreInfoDic._Key.equals(_key))
			{
				val=moreInfoDic._Value;
				
				
			}
		
		}
		
		System.out.println("amtttt"+val);
		System.out.println("amtttt"+new BigDecimal(val));

		return new BigDecimal(val);
	}
	
	public void setMoreInfo( ArrayList<MoreInfoDic>  moreInfo) {
		System.out.println("amtttt");;

		this.moreInfo = moreInfo;
	}

	private Chamber chamber;
	public Chamber getChamber() {
		return chamber;
	}

	public void setChamber(Chamber chamber) {
		this.chamber = chamber;
	}

	public Charity getCharity() {
		return charity;
	}

	public void setCharity(Charity charity) {
		this.charity = charity;
	}

	public Government getGovernment() {
		return government;
	}

	public void setGovernment(Government government) {
		this.government = government;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	private Charity charity;
	private Government government;
	private Company company;
	
	
	public InquiryRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	public String getTypeOfInquiredParty() {
		System.out.println(this.typeOfInquiredParty);
		if(this.typeOfInquiredParty.equals("IND"))
		{
		this.typeOfInquiredParty="Natural Person";
		}
		else if (this.typeOfInquiredParty.equals("CES"))
		{
		this.typeOfInquiredParty="Company";
		System.out.println("ccccccc"+this.typeOfInquiredParty);
		}
		else if (this.typeOfInquiredParty.equals("GOV"))
		{
			this.typeOfInquiredParty="Government";
		}
		else if (this.typeOfInquiredParty.equals("COC"))
		{
			this.typeOfInquiredParty="Chambers";
		}
		else  if (this.typeOfInquiredParty.equals("CAP"))
		{
			this.typeOfInquiredParty="Charities";
		}
		System.out.println(this.typeOfInquiredParty);
		return typeOfInquiredParty;
	}

	public void setTypeOfInquiredParty(String typeOfInquiredParty) {
		this.typeOfInquiredParty = typeOfInquiredParty;
	}
	
}
