package hr.croz.sama;

public class MoreInfoDic {
public String _Key;
public String _Value;

}
