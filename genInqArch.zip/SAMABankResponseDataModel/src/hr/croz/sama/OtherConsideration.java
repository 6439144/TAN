package hr.croz.sama;

public enum OtherConsideration {
  Yes,No,NA
}
