package hr.croz.sama;

public class OtherInvolvedParties {
	private String Id;
	private String InquiredPartyName;
	private String InquiredPartyIdType;

	
	
	public OtherInvolvedParties() {
		super();// TODO Auto-generated constructor stub
	}
	
	
	public String getId() {
		return Id;
	}
	public void setId(String id) {
		Id = id;
	}
	public String getInquiredPartyName() {
		return InquiredPartyName;
	}
	public void setInquiredPartyName(String inquiredPartyName) {
		InquiredPartyName = inquiredPartyName;
	}
	public String getInquiredPartyIdType() {
		return InquiredPartyIdType;
	}
	public void setInquiredPartyIdType(String inquiredPartyIdType) {
		InquiredPartyIdType = inquiredPartyIdType;
	}
}
