package hr.croz.sama;

public class Person {
	private String firstName;
	private String secondName;
	private String thirdName;
	private String lastName;
	private  String id;
	private String personIDType;
	
	public String getPersonIDType() {
		return personIDType;
	}
	public void setPersonIDType(String personIDType) {
		this.personIDType = personIDType;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Person() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Person(String firstName, String secondName, String thirdName,
			String lastName) {
		super();
		this.firstName = firstName;
		this.secondName = secondName;
		this.thirdName = thirdName;
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getSecondName() {
		return secondName;
	}
	public void setSecondName(String secondName) {
		this.secondName = secondName;
	}
	public String getThirdName() {
		return thirdName;
	}
	public void setThirdName(String thirdName) {
		this.thirdName = thirdName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getFullName() {
		String fullName = firstName;
		if (secondName != null && secondName != "") {
			fullName += " " + secondName;
		}
		if (thirdName != null && thirdName != "") {
			fullName += " " + thirdName;
		}
		if (lastName != null && lastName != "") {
			fullName += " " + lastName;
		}
		return fullName;
	}
	
}
