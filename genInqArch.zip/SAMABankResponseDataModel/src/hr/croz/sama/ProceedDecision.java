package hr.croz.sama;

public class ProceedDecision {
	
	private String message;
 public ProceedDecision() {
	
	 super();// TODO Auto-generated constructor stub
}
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
